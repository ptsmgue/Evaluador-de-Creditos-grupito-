-- OJO: conexion.txt del proyecto apunta a "evaluadorcredito" y tu dump se llama "evaluadorcrediticio".
-- Cambiá el nombre en la línea USE de abajo (o en conexion.txt) para que coincidan.

-- Ejecutar UNA vez sobre la base de datos del proyecto.
-- Agrega el rol a la tabla `usuario`, evita nombres repetidos
-- y crea un admin y un usuario de prueba (contraseña de ambos: 1234).

USE evaluadorcrediticio;

ALTER TABLE usuario
  MODIFY nombreUsuario VARCHAR(200) NOT NULL,
  MODIFY contrasena    VARCHAR(200) NOT NULL,
  ADD COLUMN rol ENUM('ADMIN','USUARIO') NOT NULL DEFAULT 'USUARIO',
  ADD UNIQUE KEY uq_usuario_nombre (nombreUsuario);

-- Las contraseñas se guardan como SHA-256 (64 caracteres hex),
-- igual que lo hace Usuario.java
INSERT INTO usuario (nombreUsuario, contrasena, rol) VALUES
  ('admin',   SHA2('1234', 256), 'ADMIN'),
  ('usuario', SHA2('1234', 256), 'USUARIO');
