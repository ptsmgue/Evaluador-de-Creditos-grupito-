/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.evaluadorcrediticio; 
import java.util.Scanner;
import java.io.IOException;
import java.io.UncheckedIOException;
/**
 *
 * @author Miguel
 */
public class EvaluadorCrediticio {

    static Cliente cliente;
    static Persona persona;
    static Usuario usuario;
    static ConexionBDD conexion;
    static Empresa empresa;

    /**
     * Conexión compartida por todas las ventanas. Se crea la primera vez que se pide
     * (lee conexion.txt), así también funciona si se ejecuta una ventana por separado.
     */
    public static synchronized ConexionBDD getConexion() {
        if (conexion == null) {
            try {
                conexion = new ConexionBDD();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
        return conexion;
    }

    public static void main(String[] args) {
        // Arranca por la ventana de login; desde ahí se abre el resto según el rol.
        VentanaLogin.main(args);
    }

public static void ingresarCliente(Scanner sc){
    System.out.println("¿Quiere ingresar una empresa o una persona? (E/P)");
    String opcion = sc.nextLine();

    if (opcion.equalsIgnoreCase("P")) {
        Persona p = new Persona();
        p.setConexion(getConexion());
        //p.ingresarCliente(); // Llama a pedir datos y luego hace el alta internamente
        //p.altaPersona();
        p.bajaCliente();
        p.bajaPersona();
    } else if (opcion.equalsIgnoreCase("E")) {
        System.out.println("Aun no we");
    }
    }
}
