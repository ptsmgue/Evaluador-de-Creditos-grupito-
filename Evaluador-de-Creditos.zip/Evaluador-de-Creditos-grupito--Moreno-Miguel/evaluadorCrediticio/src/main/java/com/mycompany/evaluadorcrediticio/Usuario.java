package com.mycompany.evaluadorcrediticio;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;

/**
 * Usuario del sistema. Un objeto Usuario representa a la persona que inició
 * sesión (nombreUsuario + rol). Las acciones de administración (registrar,
 * eliminar, listar) solo funcionan si ese usuario es ADMIN.
 *
 * No imprime ni lee por consola: avisa los problemas con UsuarioException,
 * cuyo mensaje está listo para mostrarse en un JOptionPane.
 */
public class Usuario {

    public static final String ROL_ADMIN = "ADMIN";
    public static final String ROL_USUARIO = "USUARIO";

    private static final int LARGO_MIN_CONTRASENA = 4;
    private static final int LARGO_MAX_CAMPO = 200; // varchar(200) en la tabla

    public int idUsuario;
    public String nombreUsuario;
    public String contrasena;
    public String rol;

    ConexionBDD conx;

    /** Error con un mensaje apto para mostrarle al usuario. */
    public static class UsuarioException extends Exception {
        public UsuarioException(String mensaje) {
            super(mensaje);
        }

        public UsuarioException(String mensaje, Throwable causa) {
            super(mensaje, causa);
        }
    }

    // ------------------------------------------------------------------
    // Constructores
    // ------------------------------------------------------------------
    public Usuario() {
    }

    public Usuario(String nombreUsuario, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
    }

    public Usuario(String nombreUsuario, String contrasena, String rol) {
        this(nombreUsuario, contrasena);
        this.rol = rol;
    }

    public void setConexion(ConexionBDD conexionDesdeMain) {
        this.conx = conexionDesdeMain;
    }

    // ------------------------------------------------------------------
    // Sesión
    // ------------------------------------------------------------------

    /**
     * Único inicio de sesión: busca el usuario y su contraseña y toma el rol
     * desde la base de datos.
     *
     * @return true si las credenciales son correctas (this queda con id, nombre y rol),
     *         false si el usuario o la contraseña no coinciden.
     */
    public boolean iniciarSesion(String nombre, String pass) throws UsuarioException {
        nombre = (nombre == null) ? "" : nombre.trim();
        if (nombre.isEmpty() || pass == null || pass.isEmpty()) {
            throw new UsuarioException("Ingresá el usuario y la contraseña.");
        }

        abrirConexion();
        String sql = "SELECT idUsuario, nombreUsuario, rol FROM usuario "
                   + "WHERE nombreUsuario = ? AND contrasena = ?";
        try (PreparedStatement ps = conx.cnx.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, hash(pass));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    this.idUsuario = rs.getInt("idUsuario");
                    this.nombreUsuario = rs.getString("nombreUsuario"); // tal como está guardado
                    this.rol = rs.getString("rol");
                    this.contrasena = null; // no guardamos la contraseña en memoria
                    return true;
                }
            }
            return false;
        } catch (SQLException e) {
            throw new UsuarioException("Error al iniciar sesión: " + e.getMessage(), e);
        } finally {
            conx.cerrar();
        }
    }

    public void cerrarSesion() {
        this.idUsuario = 0;
        this.nombreUsuario = null;
        this.contrasena = null;
        this.rol = null;
    }

    public boolean esAdmin() {
        return ROL_ADMIN.equals(this.rol);
    }

    // ------------------------------------------------------------------
    // Acciones exclusivas del Admin
    // ------------------------------------------------------------------
    public void registrarUsuario(String nombre, String pass, String nuevoRol) throws UsuarioException {
        exigirAdmin();

        nombre = (nombre == null) ? "" : nombre.trim();
        if (nombre.isEmpty() || nombre.length() > LARGO_MAX_CAMPO) {
            throw new UsuarioException("Nombre inválido: no puede estar vacío ni superar "
                    + LARGO_MAX_CAMPO + " caracteres.");
        }
        if (pass == null || pass.length() < LARGO_MIN_CONTRASENA) {
            throw new UsuarioException("Contraseña inválida: debe tener al menos "
                    + LARGO_MIN_CONTRASENA + " caracteres.");
        }
        if (!ROL_ADMIN.equals(nuevoRol) && !ROL_USUARIO.equals(nuevoRol)) {
            throw new UsuarioException("Rol inválido.");
        }

        abrirConexion();
        try {
            if (existeUsuario(nombre)) {
                throw new UsuarioException("Ya existe un usuario llamado '" + nombre + "'.");
            }

            String sql = "INSERT INTO usuario (nombreUsuario, contrasena, rol) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conx.cnx.prepareStatement(sql)) {
                ps.setString(1, nombre);
                ps.setString(2, hash(pass));
                ps.setString(3, nuevoRol);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new UsuarioException("Error al registrar el usuario: " + e.getMessage(), e);
        } finally {
            conx.cerrar();
        }
    }

    public void eliminarUsuario(String nombre) throws UsuarioException {
        exigirAdmin();

        nombre = (nombre == null) ? "" : nombre.trim();
        if (nombre.isEmpty()) {
            throw new UsuarioException("Indicá el usuario a eliminar.");
        }
        // MySQL compara sin distinguir mayúsculas, por eso equalsIgnoreCase
        if (nombre.equalsIgnoreCase(this.nombreUsuario)) {
            throw new UsuarioException("No podés eliminar tu propio usuario mientras tenés la sesión iniciada.");
        }

        abrirConexion();
        String sql = "DELETE FROM usuario WHERE nombreUsuario = ? AND idUsuario <> ?";
        try (PreparedStatement ps = conx.cnx.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setInt(2, this.idUsuario);
            if (ps.executeUpdate() == 0) {
                throw new UsuarioException("No existe ningún usuario llamado '" + nombre + "'.");
            }
        } catch (SQLException e) {
            throw new UsuarioException("Error al eliminar el usuario: " + e.getMessage(), e);
        } finally {
            conx.cerrar();
        }
    }

    /** Devuelve id, nombre y rol de todos los usuarios (nunca las contraseñas). */
    public List<Usuario> listarUsuarios() throws UsuarioException {
        exigirAdmin();

        abrirConexion();
        String sql = "SELECT idUsuario, nombreUsuario, rol FROM usuario ORDER BY idUsuario";
        try (PreparedStatement ps = conx.cnx.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<Usuario> lista = new ArrayList<>();
            while (rs.next()) {
                Usuario u = new Usuario();
                u.idUsuario = rs.getInt("idUsuario");
                u.nombreUsuario = rs.getString("nombreUsuario");
                u.rol = rs.getString("rol");
                lista.add(u);
            }
            return lista;
        } catch (SQLException e) {
            throw new UsuarioException("Error al listar los usuarios: " + e.getMessage(), e);
        } finally {
            conx.cerrar();
        }
    }

    // ------------------------------------------------------------------
    // Auxiliares
    // ------------------------------------------------------------------
    private void exigirAdmin() throws UsuarioException {
        if (!esAdmin()) {
            throw new UsuarioException("Solo un administrador puede realizar esta acción.");
        }
    }

    /** Se llama dentro de un bloque que ya abrió la conexión. */
    private boolean existeUsuario(String nombre) throws SQLException {
        String sql = "SELECT 1 FROM usuario WHERE nombreUsuario = ?";
        try (PreparedStatement ps = conx.cnx.prepareStatement(sql)) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** ConexionBDD.conectar() no lanza excepción, así que verificamos que quedó abierta. */
    private void abrirConexion() throws UsuarioException {
        if (conx == null) {
            throw new UsuarioException("No hay conexión configurada con la base de datos.");
        }
        conx.conectar();
        try {
            if (conx.cnx == null || conx.cnx.isClosed()) {
                throw new UsuarioException("No se pudo conectar a la base de datos. "
                        + "Revisá conexion.txt y que MySQL esté encendido.");
            }
        } catch (SQLException e) {
            throw new UsuarioException("No se pudo conectar a la base de datos: " + e.getMessage(), e);
        }
    }

    /** SHA-256 en hexadecimal (64 caracteres), coincide con SHA2(texto, 256) de MySQL. */
    private static String hash(String texto) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(texto.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }
}
